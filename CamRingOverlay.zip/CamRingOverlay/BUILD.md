# البناء (Build) — Cam Ring Overlay

## المتطلبات

- JDK 17
- Android SDK (compileSdk 34)
- اتصال بالإنترنت لأول مرة (لتحميل Gradle والمكتبات من Google/Maven)

## البناء محليًا

### Windows

```
gradlew.bat assembleDebug
```

### Linux / macOS

```
./gradlew assembleDebug
```

### بناء نسخة Release (غير موقّعة)

```
./gradlew assembleRelease
```

أو على Windows:

```
gradlew.bat assembleRelease
```

## مكان ملفات الـ APK بعد البناء

```
app/build/outputs/apk/debug/app-debug.apk
app/build/outputs/apk/release/app-release-unsigned.apk
```

## البناء تلقائيًا عبر GitHub Actions

المشروع يحتوي على ملف `.github/workflows/build.yml` يقوم تلقائيًا بـ:

1. تجهيز JDK 17 وGradle.
2. تنفيذ `assembleDebug` و`assembleRelease`.
3. نسخ الـ APK الناتج إلى مجلد `output/`.
4. رفعه كـ **Artifact** يمكن تحميله من تبويب **Actions** في الريبو بعد انتهاء كل تشغيل (run).

للوصول إليه:

1. ادخل على الريبو في GitHub.
2. تبويب **Actions**.
3. افتح آخر تشغيل ناجح (أخضر ✓) لـ workflow باسم **Build APK**.
4. في الأسفل، قسم **Artifacts** → حمّل `CamRingOverlay-apk`.
5. فك الضغط (zip) لتحصل على ملفي APK.

## ملاحظة حول Release APK

لم يتم إعداد أي `signing config` أو `keystore` وهمي، بناءً على طلب المشروع. الـ Release APK الناتج **غير موقّع (unsigned)** ولا يمكن تثبيته مباشرة على جهاز إلا بعد توقيعه، أو بتفعيل "تثبيت من مصادر غير معروفة" لملفات debug فقط. للاستخدام العادي، استخدم **Debug APK**.

## إصلاح مشاكل شائعة

| المشكلة | الحل |
|---|---|
| `SDK location not found` | أنشئ ملف `local.properties` وضع فيه `sdk.dir=/path/to/Android/Sdk` (غير مطلوب عند البناء عبر GitHub Actions) |
| فشل تحميل Gradle | تأكد من الاتصال بالإنترنت، أو استخدم Android Studio لفتح المشروع مباشرة (يتكفل بتحميل الـ wrapper) |
| أخطاء Compose Compiler | تأكد أن إصدار Kotlin (1.9.24) متوافق مع إصدار AGP (8.5.2) المحددين في المشروع |
