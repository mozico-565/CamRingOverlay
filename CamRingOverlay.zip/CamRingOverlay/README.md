# Cam Ring Overlay

تطبيق أندرويد يعرض مؤشرًا دائريًا أنيقًا حول فتحة الكاميرا الأمامية (Punch Hole)، مصمم خصوصًا لهاتف **Huawei Nova 7i**.

## الوصف

المؤشر يتكون من عنصرين يشتركان في نفس المسار الدائري حول الكاميرا:

- **Battery Arc** — قوس رفيع يمثل نسبة البطارية الحالية.
- **4 Wi-Fi Dots** — بالضبط أربع نقاط تمثل قوة إشارة Wi-Fi (0 إلى 4 مستويات).

التطبيق يعمل بالكامل **Offline**، بدون Firebase أو Backend أو Analytics أو أي اتصال إنترنت.

## المميزات (Features)

- Battery Ring يتحدث تلقائيًا عند تغيّر نسبة البطارية (Event-driven، بدون Polling).
- بالضبط 4 نقاط Wi-Fi، تتحدث عند تغيّر قوة الإشارة فقط.
- تخصيص كامل للألوان: لون موحّد أو ألوان منفصلة للبطارية والـ Wi-Fi.
- Color Picker داخلي (Hue / Saturation / Value + إدخال Hex) + ألوان جاهزة (Presets).
- Opacity قابل للتعديل (20% – 100%).
- **Calibration Mode**: تحكم مباشر (Live) بالموضع، الحجم، السماكة، والزوايا مع معاينة فورية.
- Quick Settings Tile لتشغيل/إيقاف المؤشر من شريط الإشعارات.
- Start on Boot (تشغيل تلقائي بعد إعادة التشغيل).
- شاشة **Huawei Setup** لضبط إعدادات البطارية بحيث لا يوقف EMUI الخدمة.
- Foreground Service خفيف بدون أي Loop أو Timer سريع — استهلاك بطارية منخفض جدًا.

## الأنظمة المدعومة

- الهدف الأساسي: **Android 10 (API 29) / EMUI** — هاتف Huawei Nova 7i.
- الحد الأدنى: Android 8.0 (API 26).
- يدعم أيضًا الإصدارات الأحدث حتى Android 14 (API 34).

## ملاحظات خاصة بـ Huawei Nova 7i

القيم الافتراضية لموضع المؤشر مضبوطة لتقارب مكان الكاميرا في أعلى يسار الشاشة في Nova 7i، لكنها **ليست ثابتة** — استخدم **Calibration Mode** لضبطها بدقة حسب جهازك، لأن مواضع الكاميرا قد تختلف طفيفًا بين الوحدات ودقة الشاشة.

## الصلاحيات (Permissions)

| الصلاحية | السبب |
|---|---|
| `SYSTEM_ALERT_WINDOW` | عرض المؤشر فوق التطبيقات الأخرى |
| `FOREGROUND_SERVICE` | إبقاء المؤشر يعمل في الخلفية |
| `RECEIVE_BOOT_COMPLETED` | تشغيل تلقائي بعد إعادة التشغيل (اختياري) |
| `ACCESS_WIFI_STATE` | قراءة قوة إشارة Wi-Fi فقط (لا يُقرأ SSID ولا الموقع) |
| `POST_NOTIFICATIONS` | إظهار إشعار الخدمة (مطلوب في Android 13+) |

**لا يوجد** `INTERNET permission` — التطبيق لا يتصل بالإنترنت إطلاقًا ولا يجمع أي بيانات شخصية.

## المعايرة (Calibration)

من داخل التطبيق: **Calibration Mode** يعرض المؤشر مباشرة على الشاشة مع Sliders لـ:

Offset X / Offset Y / Scale / Radius / Thickness / Battery Arc Angles / Dot Size / Dot Spacing / Wi-Fi Start Angle

كل تغيير ينعكس فورًا على المؤشر الحقيقي.

## تخصيص الألوان

من **Appearance**:
- وضع لون موحّد (Unified) أو ألوان منفصلة (Separate).
- Color Picker كامل (Hue/Saturation/Value) + Hex.
- Presets: White, Cyan, Emerald, Blue, Purple, Red, Orange.
- Opacity Slider.

## Quick Settings

أضف بلاطة **Cam Ring** إلى شريط الإشعارات السريع لتشغيل/إيقاف المؤشر بضغطة واحدة.

## البناء (Build)

راجع [`BUILD.md`](BUILD.md).

## التثبيت (Installation)

راجع [`INSTALL.md`](INSTALL.md).

## هيكل المشروع

```
app/src/main/java/com/mozico/camringoverlay/
  MainActivity.kt
  overlay/        CameraRingService.kt, CameraRingView.kt, OverlayManager.kt
  battery/        BatteryMonitor.kt
  wifi/           WifiMonitor.kt
  settings/       SettingsRepository.kt, SettingsScreen.kt, AppearanceScreen.kt,
                  CalibrationScreen.kt, HuaweiSetupScreen.kt
  tile/           CameraRingTileService.kt
  receiver/       BootReceiver.kt
  ui/             theme/, components/ (ColorPicker.kt, RingPreview.kt)
```

## قيود معروفة

- على بعض أجهزة Huawei/EMUI، قد يوقف النظام الخدمة في الخلفية ما لم يتم ضبط إعدادات "Auto-launch" يدويًا (راجع شاشة Huawei Setup داخل التطبيق).
- `Release APK` غير موقّع (unsigned) — يحتاج توقيع (signing) قبل النشر على متجر أو التوزيع خارج التثبيت اليدوي.
