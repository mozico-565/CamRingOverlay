package com.mozico.camringoverlay

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.mozico.camringoverlay.overlay.CameraRingService
import com.mozico.camringoverlay.settings.SettingsRepository
import com.mozico.camringoverlay.settings.AppearanceScreen
import com.mozico.camringoverlay.settings.CalibrationScreen
import com.mozico.camringoverlay.settings.HuaweiSetupScreen
import com.mozico.camringoverlay.settings.SettingsScreen
import com.mozico.camringoverlay.ui.theme.CamRingOverlayTheme
import kotlinx.coroutines.launch

object Routes {
    const val HOME = "home"
    const val APPEARANCE = "appearance"
    const val CALIBRATION = "calibration"
    const val HUAWEI_SETUP = "huawei_setup"
}

class MainActivity : ComponentActivity() {

    private lateinit var settingsRepository: SettingsRepository

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { /* result handled by re-check on resume via recomposition trigger */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settingsRepository = SettingsRepository(applicationContext)

        setContent {
            CamRingOverlayTheme {
                val navController = rememberNavController()
                var permissionRefreshTick by remember { mutableIntStateOf(0) }

                AppNavHost(
                    navController = navController,
                    settingsRepository = settingsRepository,
                    hasOverlayPermission = { Settings.canDrawOverlays(this) },
                    onRequestOverlayPermission = {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                        overlayPermissionLauncher.launch(intent)
                    },
                    permissionRefreshTick = permissionRefreshTick,
                    onStartService = { startCamRingService() },
                    onStopService = { stopCamRingService() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Overlay permission may have changed in system settings; UI reads it live via Settings.canDrawOverlays.
    }

    private fun startCamRingService() {
        val intent = Intent(this, CameraRingService::class.java).apply {
            action = CameraRingService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopCamRingService() {
        val intent = Intent(this, CameraRingService::class.java).apply {
            action = CameraRingService.ACTION_STOP
        }
        startService(intent)
    }
}

@Composable
private fun AppNavHost(
    navController: NavHostController,
    settingsRepository: SettingsRepository,
    hasOverlayPermission: () -> Boolean,
    onRequestOverlayPermission: () -> Unit,
    permissionRefreshTick: Int,
    onStartService: () -> Unit,
    onStopService: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val settings by settingsRepository.settingsFlow.collectAsState(
        initial = com.mozico.camringoverlay.settings.CamRingSettings()
    )

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            SettingsScreen(
                settings = settings,
                hasOverlayPermission = hasOverlayPermission(),
                isServiceRunning = CameraRingService.isRunning,
                onRequestOverlayPermission = onRequestOverlayPermission,
                onToggleEnabled = { enabled ->
                    scope.launch {
                        settingsRepository.setEnabled(enabled)
                        if (enabled) onStartService() else onStopService()
                    }
                },
                onToggleStartOnBoot = { value ->
                    scope.launch { settingsRepository.setStartOnBoot(value) }
                },
                onOpenAppearance = { navController.navigate(Routes.APPEARANCE) },
                onOpenCalibration = { navController.navigate(Routes.CALIBRATION) },
                onOpenHuaweiSetup = { navController.navigate(Routes.HUAWEI_SETUP) }
            )
        }
        composable(Routes.APPEARANCE) {
            AppearanceScreen(
                settings = settings,
                onBack = { navController.popBackStack() },
                onUnifiedColorChange = { c -> scope.launch { settingsRepository.setIndicatorColor(c) } },
                onBatteryColorChange = { c -> scope.launch { settingsRepository.setBatteryRingColor(c) } },
                onWifiColorChange = { c -> scope.launch { settingsRepository.setWifiDotsColor(c) } },
                onUseSeparateColorsChange = { v -> scope.launch { settingsRepository.setUseSeparateColors(v) } },
                onOpacityChange = { v -> scope.launch { settingsRepository.setIndicatorOpacity(v) } }
            )
        }
        composable(Routes.CALIBRATION) {
            CalibrationScreen(
                settings = settings,
                onBack = { navController.popBackStack() },
                onOffsetChange = { x, y -> scope.launch { settingsRepository.setOffset(x, y) } },
                onScaleChange = { v -> scope.launch { settingsRepository.setOverallScale(v) } },
                onRadiusChange = { v -> scope.launch { settingsRepository.setRadius(v) } },
                onThicknessChange = { v -> scope.launch { settingsRepository.setThickness(v) } },
                onDotSizeChange = { v -> scope.launch { settingsRepository.setDotSize(v) } },
                onDotSpacingChange = { v -> scope.launch { settingsRepository.setDotAngleSpacing(v) } },
                onWifiStartAngleChange = { v -> scope.launch { settingsRepository.setWifiStartAngle(v) } },
                onBatteryStartAngleChange = { v -> scope.launch { settingsRepository.setBatteryArcStartAngle(v) } },
                onBatteryMaxSweepChange = { v -> scope.launch { settingsRepository.setBatteryArcMaxSweep(v) } },
                onReset = { scope.launch { settingsRepository.resetToNova7iDefaults() } }
            )
        }
        composable(Routes.HUAWEI_SETUP) {
            HuaweiSetupScreen(onBack = { navController.popBackStack() })
        }
    }
}
