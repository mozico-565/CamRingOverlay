package com.mozico.camringoverlay.battery

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

/**
 * Event-driven battery percentage monitor. Registers a receiver for
 * ACTION_BATTERY_CHANGED (a sticky broadcast, so registering also delivers
 * the current state immediately) and notifies a callback only when the
 * percentage changes. No polling / timers are used.
 */
class BatteryMonitor(
    private val context: Context,
    private val onPercentChanged: (Int) -> Unit
) {
    private var lastPercent: Int = -1
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level < 0 || scale <= 0) return

            val percent = ((level.toFloat() / scale.toFloat()) * 100f).toInt().coerceIn(0, 100)
            if (percent != lastPercent) {
                lastPercent = percent
                onPercentChanged(percent)
            }
        }
    }

    fun start() {
        if (registered) return
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        context.registerReceiver(receiver, filter)
        registered = true
    }

    fun stop() {
        if (!registered) return
        try {
            context.unregisterReceiver(receiver)
        } catch (_: Exception) {
        }
        registered = false
    }
}
