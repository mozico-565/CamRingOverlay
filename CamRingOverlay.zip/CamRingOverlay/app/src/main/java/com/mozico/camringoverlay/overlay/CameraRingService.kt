package com.mozico.camringoverlay.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.mozico.camringoverlay.MainActivity
import com.mozico.camringoverlay.R
import com.mozico.camringoverlay.battery.BatteryMonitor
import com.mozico.camringoverlay.settings.SettingsRepository
import com.mozico.camringoverlay.wifi.WifiMonitor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

class CameraRingService : Service() {

    companion object {
        const val ACTION_STOP = "com.mozico.camringoverlay.action.STOP"
        const val ACTION_START = "com.mozico.camringoverlay.action.START"
        private const val CHANNEL_ID = "cam_ring_service_channel"
        private const val NOTIFICATION_ID = 1001

        var isRunning: Boolean = false
            private set
    }

    private lateinit var overlayManager: OverlayManager
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var batteryMonitor: BatteryMonitor
    private lateinit var wifiMonitor: WifiMonitor

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(serviceJob)

    override fun onCreate() {
        super.onCreate()
        overlayManager = OverlayManager(applicationContext)
        settingsRepository = SettingsRepository(applicationContext)

        batteryMonitor = BatteryMonitor(applicationContext) { percent ->
            overlayManager.updateBattery(percent)
        }
        wifiMonitor = WifiMonitor(applicationContext) { level ->
            overlayManager.updateWifi(level)
        }

        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelfCompletely()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        isRunning = true

        overlayManager.show()
        batteryMonitor.start()
        wifiMonitor.start()

        settingsRepository.settingsFlow
            .distinctUntilChanged()
            .onEach { settings ->
                overlayManager.applySettings(settings)
                if (!settings.enabled) {
                    stopSelfCompletely()
                }
            }
            .launchIn(serviceScope)

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        batteryMonitor.stop()
        wifiMonitor.stop()
        overlayManager.hide()
        serviceJob.cancel()
        super.onDestroy()
    }

    private fun stopSelfCompletely() {
        serviceScope.launch {
            settingsRepository.setEnabled(false)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_MIN
            )
            channel.setShowBadge(false)
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, CameraRingService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tile_ring)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_active_text))
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setContentIntent(contentIntent)
            .addAction(0, getString(R.string.notification_action_turn_off), stopPendingIntent)
            .build()
    }
}
