package com.mozico.camringoverlay.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/**
 * Lightweight custom View that draws:
 *  - a Battery Arc representing battery percentage
 *  - exactly 4 Wi-Fi dots on the same circular path
 *
 * Drawing only happens on invalidate() calls triggered by external state changes
 * (battery change, wifi change, settings change) — there is no animation loop.
 */
class CameraRingView(context: Context) : View(context) {

    // --- External state, updated by CameraRingService ---
    var batteryPercent: Int = 100
        set(value) {
            field = value.coerceIn(0, 100)
            invalidate()
        }

    var wifiLevel: Int = 0 // 0..4
        set(value) {
            field = value.coerceIn(0, 4)
            invalidate()
        }

    // --- Geometry (already converted to px by OverlayManager before assignment) ---
    var centerXPx: Float = 0f
    var centerYPx: Float = 0f
    var radiusPx: Float = 0f
    var thicknessPx: Float = 0f
    var dotRadiusPx: Float = 0f
    var dotAngleSpacingDeg: Float = 26f
    var wifiStartAngleDeg: Float = 40f
    var batteryArcStartAngleDeg: Float = 270f
    var batteryArcMaxSweepDeg: Float = 300f

    // --- Colors ---
    var batteryRingColor: Int = 0xFFFFFFFF.toInt()
    var wifiDotsColor: Int = 0xFFFFFFFF.toInt()
    var opacity: Float = 1.0f // 0.2 .. 1.0

    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val arcRect = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawBatteryArc(canvas)
        drawWifiDots(canvas)
    }

    private fun drawBatteryArc(canvas: Canvas) {
        if (radiusPx <= 0f) return

        arcRect.set(
            centerXPx - radiusPx,
            centerYPx - radiusPx,
            centerXPx + radiusPx,
            centerYPx + radiusPx
        )

        val actualSweep = batteryArcMaxSweepDeg * (batteryPercent / 100f)

        arcPaint.strokeWidth = thicknessPx
        arcPaint.color = batteryRingColor
        arcPaint.alpha = (255 * opacity).toInt().coerceIn(0, 255)

        canvas.drawArc(
            arcRect,
            batteryArcStartAngleDeg,
            actualSweep,
            false,
            arcPaint
        )
    }

    private fun drawWifiDots(canvas: Canvas) {
        if (radiusPx <= 0f) return

        val activeAlphaBase = (255 * opacity).toInt().coerceIn(0, 255)
        val inactiveAlpha = (activeAlphaBase * 0.25f).toInt().coerceIn(0, 255)

        for (i in 0 until 4) {
            val angleDeg = wifiStartAngleDeg + i * dotAngleSpacingDeg
            val angleRad = Math.toRadians(angleDeg.toDouble())

            val x = centerXPx + radiusPx * cos(angleRad).toFloat()
            val y = centerYPx + radiusPx * sin(angleRad).toFloat()

            val isActive = i < wifiLevel

            dotPaint.color = wifiDotsColor
            dotPaint.alpha = if (isActive) activeAlphaBase else inactiveAlpha

            canvas.drawCircle(x, y, dotRadiusPx, dotPaint)
        }
    }
}
