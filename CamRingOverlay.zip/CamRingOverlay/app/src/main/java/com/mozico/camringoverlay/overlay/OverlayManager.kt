package com.mozico.camringoverlay.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.WindowManager
import com.mozico.camringoverlay.settings.CamRingSettings

/**
 * Owns the overlay WindowManager window and the CameraRingView inside it.
 * Non-touchable, non-focusable, always-on-top overlay that never blocks
 * touches to the apps underneath and never steals focus or blocks the
 * status bar / notification shade.
 */
class OverlayManager(private val context: Context) {

    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var ringView: CameraRingView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var attached = false

    fun show() {
        if (attached) return

        val view = CameraRingView(context)
        ringView = view

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        layoutParams = params

        try {
            windowManager.addView(view, params)
            attached = true
        } catch (e: Exception) {
            attached = false
        }
    }

    fun hide() {
        val view = ringView ?: return
        try {
            windowManager.removeView(view)
        } catch (_: Exception) {
            // View was already detached; ignore.
        }
        ringView = null
        layoutParams = null
        attached = false
    }

    fun isShowing(): Boolean = attached

    fun updateBattery(percent: Int) {
        ringView?.batteryPercent = percent
    }

    fun updateWifi(level: Int) {
        ringView?.wifiLevel = level
    }

    /** Applies the full settings object: geometry, position and colors, converting dp to px. */
    fun applySettings(settings: CamRingSettings) {
        val view = ringView ?: return

        val scale = settings.overallScale

        val centerXPx = dpToPx(settings.offsetX)
        val centerYPx = dpToPx(settings.offsetY)
        val radiusPx = dpToPx(settings.radius) * scale
        val thicknessPx = dpToPx(settings.thickness) * scale
        val dotRadiusPx = dpToPx(settings.dotSize) * scale

        view.centerXPx = centerXPx
        view.centerYPx = centerYPx
        view.radiusPx = radiusPx
        view.thicknessPx = thicknessPx
        view.dotRadiusPx = dotRadiusPx
        view.dotAngleSpacingDeg = settings.dotAngleSpacing
        view.wifiStartAngleDeg = settings.wifiStartAngle
        view.batteryArcStartAngleDeg = settings.batteryArcStartAngle
        view.batteryArcMaxSweepDeg = settings.batteryArcMaxSweep

        view.opacity = settings.indicatorOpacity

        val batteryColor = if (settings.useSeparateColors) settings.batteryRingColor else settings.indicatorColor
        val wifiColor = if (settings.useSeparateColors) settings.wifiDotsColor else settings.indicatorColor

        view.batteryRingColor = batteryColor.toInt()
        view.wifiDotsColor = wifiColor.toInt()

        // Re-layout the window so WRAP_CONTENT bounds account for the ring's extent.
        val diameterPx = ((radiusPx + thicknessPx + dotRadiusPx) * 2).toInt().coerceAtLeast(1)
        val params = layoutParams
        if (params != null && attached) {
            params.width = diameterPx
            params.height = diameterPx
            try {
                windowManager.updateViewLayout(view, params)
            } catch (_: Exception) {
            }
        }

        view.invalidate()
    }

    private fun dpToPx(dp: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.resources.displayMetrics)
}
