package com.mozico.camringoverlay.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.mozico.camringoverlay.overlay.CameraRingService
import com.mozico.camringoverlay.settings.SettingsRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != "android.intent.action.QUICKBOOT_POWERON"
        ) {
            return
        }

        try {
            val repo = SettingsRepository(context.applicationContext)
            val settings = runBlocking { repo.settingsFlow.first() }

            if (!settings.startOnBoot) return
            if (!settings.enabled) return
            if (!Settings.canDrawOverlays(context)) return

            val serviceIntent = Intent(context, CameraRingService::class.java).apply {
                action = CameraRingService.ACTION_START
            }
            ContextCompat.startForegroundService(context, serviceIntent)
        } catch (_: Exception) {
            // Never crash on boot; overlay just won't start this time.
        }
    }
}
