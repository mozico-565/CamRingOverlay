package com.mozico.camringoverlay.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mozico.camringoverlay.ui.components.ColorPickerPanel
import com.mozico.camringoverlay.ui.components.RingPreview

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppearanceScreen(
    settings: CamRingSettings,
    onBack: () -> Unit,
    onUnifiedColorChange: (Long) -> Unit,
    onBatteryColorChange: (Long) -> Unit,
    onWifiColorChange: (Long) -> Unit,
    onUseSeparateColorsChange: (Boolean) -> Unit,
    onOpacityChange: (Float) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Appearance") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                RingPreview(settings = settings)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Use Separate Colors", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Battery ring and Wi-Fi dots use different colors",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(checked = settings.useSeparateColors, onCheckedChange = onUseSeparateColorsChange)
            }

            if (!settings.useSeparateColors) {
                Text("Indicator Color", style = MaterialTheme.typography.labelLarge)
                ColorPickerPanel(
                    initialColor = settings.indicatorColor,
                    onColorSelected = onUnifiedColorChange
                )
            } else {
                Text("Battery Ring Color", style = MaterialTheme.typography.labelLarge)
                ColorPickerPanel(
                    initialColor = settings.batteryRingColor,
                    onColorSelected = onBatteryColorChange
                )

                Divider()

                Text("Wi-Fi Dots Color", style = MaterialTheme.typography.labelLarge)
                ColorPickerPanel(
                    initialColor = settings.wifiDotsColor,
                    onColorSelected = onWifiColorChange
                )
            }

            Divider()

            Column {
                Text("Indicator Opacity", style = MaterialTheme.typography.labelLarge)
                Text(
                    "${(settings.indicatorOpacity * 100).toInt()}%",
                    style = MaterialTheme.typography.bodySmall
                )
                Slider(
                    value = settings.indicatorOpacity,
                    onValueChange = onOpacityChange,
                    valueRange = 0.2f..1.0f
                )
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}
