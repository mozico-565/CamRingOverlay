package com.mozico.camringoverlay.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mozico.camringoverlay.ui.components.RingPreview

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalibrationScreen(
    settings: CamRingSettings,
    onBack: () -> Unit,
    onOffsetChange: (Float, Float) -> Unit,
    onScaleChange: (Float) -> Unit,
    onRadiusChange: (Float) -> Unit,
    onThicknessChange: (Float) -> Unit,
    onDotSizeChange: (Float) -> Unit,
    onDotSpacingChange: (Float) -> Unit,
    onWifiStartAngleChange: (Float) -> Unit,
    onBatteryStartAngleChange: (Float) -> Unit,
    onBatteryMaxSweepChange: (Float) -> Unit,
    onReset: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Calibration Mode") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            Text(
                "The ring is showing live on your screen right now. Adjust the sliders until it sits perfectly around your camera.",
                style = MaterialTheme.typography.bodySmall
            )

            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                RingPreview(settings = settings)
            }

            LabeledSlider("Offset X", settings.offsetX, 0f..200f) { onOffsetChange(it, settings.offsetY) }
            LabeledSlider("Offset Y", settings.offsetY, 0f..200f) { onOffsetChange(settings.offsetX, it) }
            LabeledSlider("Overall Scale", settings.overallScale, 0.5f..2.0f, onScaleChange)

            Divider()

            LabeledSlider("Radius", settings.radius, 10f..60f, onRadiusChange)
            LabeledSlider("Thickness", settings.thickness, 1f..10f, onThicknessChange)
            LabeledSlider("Battery Arc Start Angle", settings.batteryArcStartAngle, 0f..360f, onBatteryStartAngleChange)
            LabeledSlider("Maximum Sweep Angle", settings.batteryArcMaxSweep, 60f..360f, onBatteryMaxSweepChange)

            Divider()

            LabeledSlider("Dot Size", settings.dotSize, 1f..8f, onDotSizeChange)
            LabeledSlider("Dot Angle Spacing", settings.dotAngleSpacing, 5f..60f, onDotSpacingChange)
            LabeledSlider("Wi-Fi Start Angle", settings.wifiStartAngle, 0f..360f, onWifiStartAngleChange)

            Spacer(Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilledTonalButton(onClick = onReset, modifier = Modifier.weight(1f)) {
                    Text("Reset Calibration")
                }
                Button(onClick = onBack, modifier = Modifier.weight(1f)) {
                    Text("Save Calibration")
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.labelLarge)
            Text(String.format("%.1f", value), style = MaterialTheme.typography.bodySmall)
        }
        Slider(value = value, onValueChange = onValueChange, valueRange = range)
    }
}
