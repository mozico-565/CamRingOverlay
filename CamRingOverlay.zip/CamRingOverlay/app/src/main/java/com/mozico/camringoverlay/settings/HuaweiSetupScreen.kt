package com.mozico.camringoverlay.settings

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HuaweiSetupScreen(onBack: () -> Unit) {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Huawei Setup") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            Text(
                "EMUI aggressively closes background services to save battery. " +
                    "To keep Cam Ring running reliably, allow it to run in the background manually.",
                style = MaterialTheme.typography.bodyMedium
            )

            InfoStep(
                number = 1,
                title = "Open App Launch settings",
                body = "Settings → Battery → App launch → find \"Cam Ring Overlay\""
            )
            InfoStep(
                number = 2,
                title = "Switch to Manage manually",
                body = "Turn off the automatic toggle to reveal manual controls."
            )
            InfoStep(
                number = 3,
                title = "Enable all three",
                body = "Auto-launch, Secondary launch, and Run in background — all ON."
            )
            InfoStep(
                number = 4,
                title = "Names may vary",
                body = "Depending on your EMUI/Android version, these settings may be labeled slightly differently, but they live under Battery → App launch."
            )

            Button(
                onClick = {
                    try {
                        val intent = Intent(Intent.ACTION_MAIN).apply {
                            component = android.content.ComponentName(
                                "com.huawei.systemmanager",
                                "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
                            )
                        }
                        context.startActivity(intent)
                    } catch (_: ActivityNotFoundException) {
                        try {
                            val fallback = Intent(Intent.ACTION_MAIN).apply {
                                component = android.content.ComponentName(
                                    "com.huawei.systemmanager",
                                    "com.huawei.systemmanager.mainscreen.MainScreenActivity"
                                )
                            }
                            context.startActivity(fallback)
                        } catch (_: Exception) {
                            // No matching activity on this device/ROM — user follows the manual steps above.
                        }
                    }
                }
            ) {
                Text("Try Opening Huawei App Launch Settings")
            }

            Text(
                "If the button above doesn't open anything on your device, use the manual steps in Settings instead.",
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun InfoStep(number: Int, title: String, body: String) {
    ElevatedCard(shape = RoundedCornerShape(14.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("$number. $title", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(body, style = MaterialTheme.typography.bodySmall)
        }
    }
}
