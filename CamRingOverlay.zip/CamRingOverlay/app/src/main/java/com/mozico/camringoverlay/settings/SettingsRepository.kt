package com.mozico.camringoverlay.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** DataStore instance, scoped to the application Context. */
val Context.settingsDataStore by preferencesDataStore(name = "cam_ring_settings")

/**
 * Full set of user-configurable settings for the overlay.
 * Colors are stored as ARGB Long values (0xAARRGGBB).
 */
data class CamRingSettings(
    val enabled: Boolean = false,
    val startOnBoot: Boolean = false,

    // Position (dp, relative to top-left of the screen)
    val offsetX: Float = Defaults.NOVA7I_OFFSET_X,
    val offsetY: Float = Defaults.NOVA7I_OFFSET_Y,
    val overallScale: Float = 1.0f,

    // Ring geometry (dp)
    val radius: Float = Defaults.NOVA7I_RADIUS,
    val thickness: Float = 3.5f,
    val batteryArcStartAngle: Float = 270f,
    val batteryArcMaxSweep: Float = 300f,

    // Wi-Fi dots geometry
    val dotSize: Float = 3.2f,
    val dotAngleSpacing: Float = 26f,
    val wifiStartAngle: Float = 40f,

    // Colors (ARGB)
    val indicatorColor: Long = 0xFFFFFFFF,
    val batteryRingColor: Long = 0xFFFFFFFF,
    val wifiDotsColor: Long = 0xFFFFFFFF,
    val useSeparateColors: Boolean = false,
    val indicatorOpacity: Float = 1.0f
)

/** Reasonable starting defaults for the Huawei Nova 7i punch-hole camera position. */
object Defaults {
    const val NOVA7I_OFFSET_X = 38f
    const val NOVA7I_OFFSET_Y = 38f
    const val NOVA7I_RADIUS = 22f
}

class SettingsRepository(private val context: Context) {

    private object Keys {
        val ENABLED = booleanPreferencesKey("enabled")
        val START_ON_BOOT = booleanPreferencesKey("start_on_boot")

        val OFFSET_X = floatPreferencesKey("offset_x")
        val OFFSET_Y = floatPreferencesKey("offset_y")
        val OVERALL_SCALE = floatPreferencesKey("overall_scale")

        val RADIUS = floatPreferencesKey("radius")
        val THICKNESS = floatPreferencesKey("thickness")
        val BATTERY_ARC_START_ANGLE = floatPreferencesKey("battery_arc_start_angle")
        val BATTERY_ARC_MAX_SWEEP = floatPreferencesKey("battery_arc_max_sweep")

        val DOT_SIZE = floatPreferencesKey("dot_size")
        val DOT_ANGLE_SPACING = floatPreferencesKey("dot_angle_spacing")
        val WIFI_START_ANGLE = floatPreferencesKey("wifi_start_angle")

        val INDICATOR_COLOR = longPreferencesKey("indicator_color")
        val BATTERY_RING_COLOR = longPreferencesKey("battery_ring_color")
        val WIFI_DOTS_COLOR = longPreferencesKey("wifi_dots_color")
        val USE_SEPARATE_COLORS = booleanPreferencesKey("use_separate_colors")
        val INDICATOR_OPACITY = floatPreferencesKey("indicator_opacity")
    }

    val settingsFlow: Flow<CamRingSettings> = context.settingsDataStore.data.map { prefs ->
        CamRingSettings(
            enabled = prefs[Keys.ENABLED] ?: false,
            startOnBoot = prefs[Keys.START_ON_BOOT] ?: false,
            offsetX = prefs[Keys.OFFSET_X] ?: Defaults.NOVA7I_OFFSET_X,
            offsetY = prefs[Keys.OFFSET_Y] ?: Defaults.NOVA7I_OFFSET_Y,
            overallScale = prefs[Keys.OVERALL_SCALE] ?: 1.0f,
            radius = prefs[Keys.RADIUS] ?: Defaults.NOVA7I_RADIUS,
            thickness = prefs[Keys.THICKNESS] ?: 3.5f,
            batteryArcStartAngle = prefs[Keys.BATTERY_ARC_START_ANGLE] ?: 270f,
            batteryArcMaxSweep = prefs[Keys.BATTERY_ARC_MAX_SWEEP] ?: 300f,
            dotSize = prefs[Keys.DOT_SIZE] ?: 3.2f,
            dotAngleSpacing = prefs[Keys.DOT_ANGLE_SPACING] ?: 26f,
            wifiStartAngle = prefs[Keys.WIFI_START_ANGLE] ?: 40f,
            indicatorColor = prefs[Keys.INDICATOR_COLOR] ?: 0xFFFFFFFF,
            batteryRingColor = prefs[Keys.BATTERY_RING_COLOR] ?: 0xFFFFFFFF,
            wifiDotsColor = prefs[Keys.WIFI_DOTS_COLOR] ?: 0xFFFFFFFF,
            useSeparateColors = prefs[Keys.USE_SEPARATE_COLORS] ?: false,
            indicatorOpacity = prefs[Keys.INDICATOR_OPACITY] ?: 1.0f
        )
    }

    suspend fun setEnabled(value: Boolean) = update { it[Keys.ENABLED] = value }
    suspend fun setStartOnBoot(value: Boolean) = update { it[Keys.START_ON_BOOT] = value }

    suspend fun setOffset(x: Float, y: Float) = update {
        it[Keys.OFFSET_X] = x
        it[Keys.OFFSET_Y] = y
    }

    suspend fun setOverallScale(value: Float) = update { it[Keys.OVERALL_SCALE] = value }
    suspend fun setRadius(value: Float) = update { it[Keys.RADIUS] = value }
    suspend fun setThickness(value: Float) = update { it[Keys.THICKNESS] = value }
    suspend fun setBatteryArcStartAngle(value: Float) = update { it[Keys.BATTERY_ARC_START_ANGLE] = value }
    suspend fun setBatteryArcMaxSweep(value: Float) = update { it[Keys.BATTERY_ARC_MAX_SWEEP] = value }

    suspend fun setDotSize(value: Float) = update { it[Keys.DOT_SIZE] = value }
    suspend fun setDotAngleSpacing(value: Float) = update { it[Keys.DOT_ANGLE_SPACING] = value }
    suspend fun setWifiStartAngle(value: Float) = update { it[Keys.WIFI_START_ANGLE] = value }

    suspend fun setIndicatorColor(value: Long) = update { it[Keys.INDICATOR_COLOR] = value }
    suspend fun setBatteryRingColor(value: Long) = update { it[Keys.BATTERY_RING_COLOR] = value }
    suspend fun setWifiDotsColor(value: Long) = update { it[Keys.WIFI_DOTS_COLOR] = value }
    suspend fun setUseSeparateColors(value: Boolean) = update { it[Keys.USE_SEPARATE_COLORS] = value }
    suspend fun setIndicatorOpacity(value: Float) = update { it[Keys.INDICATOR_OPACITY] = value }

    /** Resets calibration/appearance values to the Huawei Nova 7i defaults, keeps enabled/startOnBoot. */
    suspend fun resetToNova7iDefaults() = update {
        it[Keys.OFFSET_X] = Defaults.NOVA7I_OFFSET_X
        it[Keys.OFFSET_Y] = Defaults.NOVA7I_OFFSET_Y
        it[Keys.OVERALL_SCALE] = 1.0f
        it[Keys.RADIUS] = Defaults.NOVA7I_RADIUS
        it[Keys.THICKNESS] = 3.5f
        it[Keys.BATTERY_ARC_START_ANGLE] = 270f
        it[Keys.BATTERY_ARC_MAX_SWEEP] = 300f
        it[Keys.DOT_SIZE] = 3.2f
        it[Keys.DOT_ANGLE_SPACING] = 26f
        it[Keys.WIFI_START_ANGLE] = 40f
    }

    private suspend fun update(block: (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        context.settingsDataStore.edit { block(it) }
    }
}
