package com.mozico.camringoverlay.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: CamRingSettings,
    hasOverlayPermission: Boolean,
    isServiceRunning: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onToggleEnabled: (Boolean) -> Unit,
    onToggleStartOnBoot: (Boolean) -> Unit,
    onOpenAppearance: () -> Unit,
    onOpenCalibration: () -> Unit,
    onOpenHuaweiSetup: () -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Cam Ring Overlay") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            ElevatedCard(shape = RoundedCornerShape(16.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Enable Camera Ring", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Shows the battery + Wi-Fi ring around your camera",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(
                        checked = settings.enabled,
                        onCheckedChange = { enabled ->
                            if (enabled && !hasOverlayPermission) {
                                onRequestOverlayPermission()
                            } else {
                                onToggleEnabled(enabled)
                            }
                        }
                    )
                }
            }

            Text("Status", style = MaterialTheme.typography.labelLarge)

            StatusCard(
                title = "Overlay Permission",
                subtitle = if (hasOverlayPermission) "Granted" else "Required to show the ring",
                isOk = hasOverlayPermission,
                actionLabel = if (!hasOverlayPermission) "Grant" else null,
                onAction = onRequestOverlayPermission
            )

            StatusCard(
                title = "Service Running",
                subtitle = if (isServiceRunning) "Active" else "Stopped",
                isOk = isServiceRunning
            )

            StatusCard(
                title = "Battery Optimization",
                subtitle = "Recommended: disable for reliable background operation",
                isOk = null,
                actionLabel = "Huawei Setup",
                onAction = onOpenHuaweiSetup
            )

            StatusCard(
                title = "Start on Boot",
                subtitle = if (settings.startOnBoot) "Enabled" else "Disabled",
                isOk = settings.startOnBoot,
                trailing = {
                    Switch(
                        checked = settings.startOnBoot,
                        onCheckedChange = onToggleStartOnBoot
                    )
                }
            )

            Spacer(Modifier.height(8.dp))
            Text("Customize", style = MaterialTheme.typography.labelLarge)

            NavRow(title = "Appearance", subtitle = "Color, opacity, presets", onClick = onOpenAppearance)
            NavRow(title = "Calibration", subtitle = "Position, size, angles — live preview", onClick = onOpenCalibration)
            NavRow(title = "Huawei Setup", subtitle = "Keep the service alive on EMUI", onClick = onOpenHuaweiSetup)

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun StatusCard(
    title: String,
    subtitle: String,
    isOk: Boolean?,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    ElevatedCard(shape = RoundedCornerShape(14.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall)
            }
            when {
                trailing != null -> trailing()
                actionLabel != null && onAction != null -> TextButton(onClick = onAction) { Text(actionLabel) }
                isOk != null -> Text(if (isOk) "✓" else "✕")
            }
        }
    }
}

@Composable
private fun NavRow(title: String, subtitle: String, onClick: () -> Unit) {
    ElevatedCard(shape = RoundedCornerShape(14.dp), onClick = onClick) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null)
        }
    }
}
