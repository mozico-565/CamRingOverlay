package com.mozico.camringoverlay.tile

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.mozico.camringoverlay.overlay.CameraRingService
import com.mozico.camringoverlay.settings.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CameraRingTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()

        if (!Settings.canDrawOverlays(this)) {
            // Can't start the overlay without permission; nothing to toggle.
            return
        }

        val running = CameraRingService.isRunning
        val repo = SettingsRepository(applicationContext)

        if (running) {
            val stopIntent = Intent(this, CameraRingService::class.java).apply {
                action = CameraRingService.ACTION_STOP
            }
            startService(stopIntent)
        } else {
            CoroutineScope(Dispatchers.Default).launch {
                repo.setEnabled(true)
            }
            val startIntent = Intent(this, CameraRingService::class.java).apply {
                action = CameraRingService.ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(startIntent)
            } else {
                startService(startIntent)
            }
        }

        // Reflect the new state immediately; onStartListening will correct it if needed.
        refreshTile(forcedActive = !running)
    }

    private fun refreshTile(forcedActive: Boolean? = null) {
        val tile = qsTile ?: return
        val active = forcedActive ?: CameraRingService.isRunning
        tile.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }
}
