package com.mozico.camringoverlay.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/** A compact preset color swatch used in the Appearance screen. */
data class ColorPreset(val name: String, val color: Long)

val PresetColors = listOf(
    ColorPreset("White", 0xFFFFFFFF),
    ColorPreset("Cyan", 0xFF00E5FF),
    ColorPreset("Emerald", 0xFF4ADE80),
    ColorPreset("Blue", 0xFF3B82F6),
    ColorPreset("Purple", 0xFFA855F7),
    ColorPreset("Red", 0xFFFF4D4D),
    ColorPreset("Orange", 0xFFFF8A3D)
)

/**
 * Self-contained HSV color picker: hue strip + saturation/value square + hex input.
 * onColorSelected is invoked live as the user drags, matching the "live update" requirement.
 */
@Composable
fun ColorPickerPanel(
    initialColor: Long,
    onColorSelected: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val initialArgb = initialColor.toInt()
    val hsv = remember { FloatArray(3) }
    remember(initialColor) {
        android.graphics.Color.colorToHSV(initialArgb, hsv)
        true
    }

    var hue by remember(initialColor) { mutableStateOf(hsv[0]) }
    var sat by remember(initialColor) { mutableStateOf(hsv[1]) }
    var value by remember(initialColor) { mutableStateOf(hsv[2]) }
    var hexText by remember(initialColor) {
        mutableStateOf(String.format("#%06X", 0xFFFFFF and initialArgb))
    }

    fun currentColorLong(): Long {
        val argb = android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, value))
        return (argb.toLong() and 0xFFFFFFFFL) or 0xFF000000L
    }

    fun emit() {
        val c = currentColorLong()
        hexText = String.format("#%06X", 0xFFFFFF and c.toInt())
        onColorSelected(c)
    }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(14.dp)) {

        // Saturation / Value square
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .clip(RoundedCornerShape(12.dp))
                .pointerInput(hue) {
                    detectDragGestures(
                        onDrag = { change, _ ->
                            val x = change.position.x.coerceIn(0f, size.width.toFloat())
                            val y = change.position.y.coerceIn(0f, size.height.toFloat())
                            sat = x / size.width
                            value = 1f - (y / size.height)
                            emit()
                        }
                    )
                }
                .pointerInput(hue) {
                    detectTapGestures { offset ->
                        val x = offset.x.coerceIn(0f, size.width.toFloat())
                        val y = offset.y.coerceIn(0f, size.height.toFloat())
                        sat = x / size.width
                        value = 1f - (y / size.height)
                        emit()
                    }
                }
        ) {
            val pureHueColor = Color.hsv(hue, 1f, 1f)
            drawRect(
                brush = Brush.horizontalGradient(listOf(Color.White, pureHueColor))
            )
            drawRect(
                brush = Brush.verticalGradient(listOf(Color.Transparent, Color.Black))
            )
            val markerX = sat * size.width
            val markerY = (1f - value) * size.height
            drawCircle(
                color = Color.White,
                radius = 8f,
                center = Offset(markerX, markerY),
                style = Stroke(width = 3f)
            )
        }

        // Hue strip
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .clip(RoundedCornerShape(14.dp))
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDrag = { change, _ ->
                            val x = change.position.x.coerceIn(0f, size.width.toFloat())
                            hue = (x / size.width) * 360f
                            emit()
                        }
                    )
                }
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val x = offset.x.coerceIn(0f, size.width.toFloat())
                        hue = (x / size.width) * 360f
                        emit()
                    }
                }
        ) {
            val hueColors = (0..360 step 30).map { Color.hsv(it.toFloat() % 360f, 1f, 1f) }
            drawRect(brush = Brush.horizontalGradient(hueColors))
            val markerX = (hue / 360f) * size.width
            drawCircle(
                color = Color.White,
                radius = size.height / 2f,
                center = Offset(markerX, size.height / 2f),
                style = Stroke(width = 3f)
            )
        }

        // Hex input + live swatch
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(currentColorLong().toInt()))
            )
            OutlinedTextField(
                value = hexText,
                onValueChange = { text ->
                    hexText = text
                    val cleaned = text.removePrefix("#").trim()
                    if (cleaned.length == 6 && cleaned.all { it.isDigit() || it.uppercaseChar() in 'A'..'F' }) {
                        try {
                            val parsed = cleaned.toLong(16) or 0xFF000000L
                            android.graphics.Color.colorToHSV(parsed.toInt(), hsv)
                            hue = hsv[0]; sat = hsv[1]; value = hsv[2]
                            onColorSelected(parsed)
                        } catch (_: NumberFormatException) {
                        }
                    }
                },
                label = { Text("Hex") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
        }

        // Presets
        Text("Presets", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PresetColors.forEach { preset ->
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(preset.color.toInt()))
                        .pointerInput(preset) {
                            detectTapGestures {
                                android.graphics.Color.colorToHSV(preset.color.toInt(), hsv)
                                hue = hsv[0]; sat = hsv[1]; value = hsv[2]
                                emit()
                            }
                        }
                )
            }
        }
    }
}
