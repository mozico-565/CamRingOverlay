package com.mozico.camringoverlay.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.mozico.camringoverlay.settings.CamRingSettings
import kotlin.math.cos
import kotlin.math.sin

/**
 * Renders a live, self-contained preview of the ring against a fake dark
 * "screen" with a fake camera punch-hole, using the same math as the
 * real overlay (CameraRingView). Used in Appearance/Calibration screens.
 */
@Composable
fun RingPreview(
    settings: CamRingSettings,
    previewBatteryPercent: Int = 82,
    previewWifiLevel: Int = 3,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .size(220.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color.Black)
    ) {
        val density = this.density
        fun dp(v: Float) = v * density

        val cx = dp(settings.offsetX)
        val cy = dp(settings.offsetY)
        val radius = dp(settings.radius) * settings.overallScale
        val thickness = dp(settings.thickness) * settings.overallScale
        val dotRadius = dp(settings.dotSize) * settings.overallScale

        // Fake camera punch-hole
        drawCircle(color = Color(0xFF050505), radius = dp(10f), center = Offset(cx, cy))

        val batteryColor = if (settings.useSeparateColors) settings.batteryRingColor else settings.indicatorColor
        val wifiColor = if (settings.useSeparateColors) settings.wifiDotsColor else settings.indicatorColor
        val opacity = settings.indicatorOpacity

        val sweep = settings.batteryArcMaxSweep * (previewBatteryPercent / 100f)

        drawArc(
            color = Color(batteryColor.toInt()).copy(alpha = opacity),
            startAngle = settings.batteryArcStartAngle,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = Offset(cx - radius, cy - radius),
            size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
            style = Stroke(width = thickness, cap = StrokeCap.Round)
        )

        for (i in 0 until 4) {
            val angleDeg = settings.wifiStartAngle + i * settings.dotAngleSpacing
            val angleRad = Math.toRadians(angleDeg.toDouble())
            val x = cx + radius * cos(angleRad).toFloat()
            val y = cy + radius * sin(angleRad).toFloat()
            val active = i < previewWifiLevel
            val alpha = if (active) opacity else opacity * 0.25f
            drawCircle(
                color = Color(wifiColor.toInt()).copy(alpha = alpha),
                radius = dotRadius,
                center = Offset(x, y)
            )
        }
    }
}
