package com.mozico.camringoverlay.ui.theme

import androidx.compose.ui.graphics.Color

val AccentCyan = Color(0xFF00E5FF)
val BackgroundDark = Color(0xFF0B0B0F)
val SurfaceDark = Color(0xFF16161C)
val OnSurfaceDark = Color(0xFFEDEDF2)
val MutedDark = Color(0xFF8A8A94)
