package com.mozico.camringoverlay.wifi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build

/**
 * Event-driven Wi-Fi signal level monitor.
 *
 * Only reads RSSI to derive a 0..4 signal level via WifiManager.calculateSignalLevel().
 * Never reads or stores SSID, BSSID, or location data, and requests no location
 * permission — only ACCESS_WIFI_STATE.
 *
 * Updates are driven by system broadcasts (RSSI changes, network state changes);
 * there is no polling loop.
 */
class WifiMonitor(
    private val context: Context,
    private val onLevelChanged: (Int) -> Unit
) {
    companion object {
        private const val MAX_LEVEL = 4
    }

    private val wifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private var lastLevel: Int = -1
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            emitCurrentLevel()
        }
    }

    fun start() {
        if (registered) return
        val filter = IntentFilter().apply {
            addAction(WifiManager.RSSI_CHANGED_ACTION)
            addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
            addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        }
        context.registerReceiver(receiver, filter)
        registered = true
        emitCurrentLevel()
    }

    fun stop() {
        if (!registered) return
        try {
            context.unregisterReceiver(receiver)
        } catch (_: Exception) {
        }
        registered = false
    }

    private fun emitCurrentLevel() {
        val level = computeLevel()
        if (level != lastLevel) {
            lastLevel = level
            onLevelChanged(level)
        }
    }

    private fun computeLevel(): Int {
        val manager = wifiManager ?: return 0
        if (!isWifiConnected()) return 0

        val rssi = try {
            @Suppress("DEPRECATION")
            manager.connectionInfo?.rssi ?: return 0
        } catch (_: Exception) {
            return 0
        }

        if (rssi == 0 || rssi == Int.MIN_VALUE) return 0

        return try {
            manager.calculateSignalLevel(rssi, MAX_LEVEL + 1)
        } catch (_: Exception) {
            0
        }.coerceIn(0, MAX_LEVEL)
    }

    private fun isWifiConnected(): Boolean {
        val cm = context.applicationContext
            .getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } else {
            @Suppress("DEPRECATION")
            val info = cm.activeNetworkInfo
            @Suppress("DEPRECATION")
            info != null && info.isConnected && info.type == ConnectivityManager.TYPE_WIFI
        }
    }
}
